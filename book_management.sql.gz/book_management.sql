-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2022 at 09:24 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `book_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_book`
--

CREATE TABLE `add_book` (
  `id` int(11) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `isbn` varchar(100) DEFAULT NULL,
  `genre` varchar(100) DEFAULT NULL,
  `quantity` varchar(50) DEFAULT NULL,
  `shelf_number` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_book`
--

INSERT INTO `add_book` (`id`, `title`, `author`, `isbn`, `genre`, `quantity`, `shelf_number`) VALUES
(74, 'Harry Potter 1', 'J.K Rowling', 'ISBN 123 456 789', 'Fiction', '1', '001'),
(75, 'Harry Potter 2', 'J.K Rowling', 'ISBN 123 456 789', 'Fiction', '1', '001'),
(78, 'Harry Potter 3', 'J.K Rowling', 'ISBN 123 456 789', 'Fiction', '1', '001'),
(82, 'Harry Potter', 'J.K Rowling', 'ISBN 123 456 789', 'Fiction', '2', '002'),
(86, 'asdfgdsafg', 'dfgsDGsd', 'gsdGsdGsDGSDGsdg', 'sdgsdgsd', 'gsdgsdg', 'sdgsdg');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'administrator', 'evsunista');

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

CREATE TABLE `borrow` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `year` varchar(20) DEFAULT NULL,
  `section` varchar(100) DEFAULT NULL,
  `id_number` varchar(30) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `isbn` varchar(200) DEFAULT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `shelf_number` varchar(255) DEFAULT NULL,
  `date_borrowed` varchar(255) DEFAULT NULL,
  `date_returned` varchar(255) DEFAULT NULL,
  `uniq_code` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `borrow`
--

INSERT INTO `borrow` (`id`, `name`, `year`, `section`, `id_number`, `course`, `title`, `isbn`, `genre`, `shelf_number`, `date_borrowed`, `date_returned`, `uniq_code`) VALUES
(45, 'Monreal, Marvin A.', '1', 'A', '2021-32400', 'BSIT', 'Harry Potter 1', 'ISBN 123 456 789', 'Fiction', '001', '5/17/2022', '05/17/2022', 'RFyIKejAmDfRdAJ'),
(46, 'Marvin Monreal', '1', 'A', '2021-32400', 'BSIT', 'Harry Potter 1', 'ISBN 123 456 789', 'Fiction', '001', '5/17/2022', '05/17/2022', 'jtHlCsDTmGOpOpi'),
(48, 'dfgsdgf', 'sdgsdgs', 'dgsdgs', 'dgsdgsdgs', 'sdgsdgsdg', 'Harry Potter 1', 'ISBN 123 456 789', 'Fiction', '001', '5/20/2022', '05/20/2022', 'IwlkuHnwzPMNrJg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_book`
--
ALTER TABLE `add_book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `borrow`
--
ALTER TABLE `borrow`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_book`
--
ALTER TABLE `add_book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `borrow`
--
ALTER TABLE `borrow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
